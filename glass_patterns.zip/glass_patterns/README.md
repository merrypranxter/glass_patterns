# glass_patterns

> two dot fields. one transformed. global form from local randomness.

Glass pattern generator. Two identical random dot fields are overlaid; one field has a subset of dots transformed (rotated, scaled, or radially displaced). The global structure is invisible in any local region but emerges instantly from the correlation across the field. The brain detects this structure using mechanisms similar to those for optic flow and motion coherence. Parameterize transformation type, dot density, and correlation strength.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Cycle transformation (rotation / scaling / radial / concentric) |
| `+ / -` | Increase / decrease dot density |
| `↑ / ↓` | Increase / decrease transformation strength |
| `C` | Adjust correlation proportion (0.0–1.0) |
| `S` | Toggle single-field view ( destroys illusion) |
| `A` | Animate transformation continuously |

## Named Regimes

- **Rotation** — Dots rotated about center by fixed angle
- **Scaling** — Radial expansion or contraction
- **Radial** — Tangential displacement (spiral)
- **Concentric** — Circular structure from correlated noise
- **Translation** — Lateral displacement (pure motion)
- **Mixed** — Multiple transformations combined

## The Math

Glass pattern generation:
- Reference field: N dots at random positions (x_i, y_i)
- Transformed field: same dots, but subset transformed
- Rotation: (x', y') = R(θ) · (x, y)
- Scaling: (x', y') = s · (x, y)
- Radial: (x', y') = (x, y) + k · (-y, x) / r

Correlation strength:
- c = 0.0: no correlation (pure noise)
- c = 1.0: all dots correlated (perfect form)
- Optimal for human detection: c ≈ 0.3–0.5

## Acknowledgments

Leon Glass (1969), *Moire Effect from Random Dots*, Wilson, Wilkinson, and others on neural mechanisms of Glass pattern detection.
