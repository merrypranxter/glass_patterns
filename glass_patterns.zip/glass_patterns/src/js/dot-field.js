// Random dot field generation
