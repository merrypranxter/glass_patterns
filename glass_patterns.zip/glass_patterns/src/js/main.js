// Glass pattern renderer
