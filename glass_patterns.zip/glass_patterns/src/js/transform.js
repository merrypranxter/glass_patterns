// Rotation, scaling, and radial displacement
