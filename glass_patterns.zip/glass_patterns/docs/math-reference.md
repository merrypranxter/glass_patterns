# Math Reference: glass_patterns

> TODO: add mathematical foundations, equations, and reference values.
